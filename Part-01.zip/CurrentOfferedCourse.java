import java.util.Arrays;

public class CurrentOfferedCourse {
	
	public CurrentOfferedCourse() {
		
	}
	
	private Course[] cList = new Course[0];
	
	public void addCourse(Course course) {
		Course[] changedCourse = Arrays.copyOf(cList, cList.length +1);
		changedCourse[cList.length] = course;
		cList = changedCourse;
	}
	
	public Course getCourse(Course course) {
		for(Course ex : cList) {
			if (ex.getTitle() == course.getTitle()) {
				return course;
			}
		}
		return null;
	}
	
	public Course[] getCourseList() {
		return cList;
	}
}
