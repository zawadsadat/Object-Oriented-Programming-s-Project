
public class Student {
	
	private String name;
	
	private int id;
	
	private double cgpa;
	
	private Registration reg;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public Registration getReg() {
		return reg;
	}

	public void setReg(Registration reg) {
		this.reg = reg;
	}

	public Student(String name, int id, double cgpa) {
		super();
		this.name = name;
		this.id = id;
		this.cgpa = cgpa;
	}
	
	public void makeNewRegistration() {
		this.reg = new Registration();
	}
	
	public void addCourse(Course course) {
		if(course.getNumOfStudent() == course.getSeatCapacity()) {
			System.out.println(course.getId()+" can not be added.Seat is Full !!");
		}
		else {
			int totalCurrentCredit = 0;
			boolean isExist = false;
			for(Course ec : this.getReg().getCourseList()) {
				totalCurrentCredit += ec.getCredit();
				if(!isExist && ec.getId() == course.getId()) {
					isExist = true;
				}
			}
			int availCredit = this.getCgpa() >= 3.5 ? 18: 12;
			if(course.getCredit() > availCredit - totalCurrentCredit) {
				System.out.println(this.getName() + ": You can not take "+ course.getId() +". You exceed the "+ availCredit +" credits limit.");
			} else if(!isExist){
				this.getReg().addCourse(course);
				course.setNumOfStudent(course.getNumOfStudent() + 1); 
			}
		}
	}
	
	public void dropCourse(Course course) {
		this.getReg().deleteCourse(course);
		course.setNumOfStudent(course.getNumOfStudent() - 1);
	}
	
	public Registration getRegistration() {
		return this.reg;
	}
	
	public String printRegisteredCourse() {
		StringBuffer allCourses = new StringBuffer();
		System.out.printf("Course Id:\tCourse Title:\n");
		System.out.println("");
		for (Course course : this.getReg().getCourseList()) {
			System.out.printf(course.getId() + "\t" + course.getTitle() + "\n");
		}
		return allCourses.toString();
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + ", cgpa=" + cgpa + ", reg=" + reg + "]";
	}
}
