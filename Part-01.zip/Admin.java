
public class Admin {
	
	private CurrentOfferedCourse currentOfferedCourse;
	
	public Admin() {
		this.currentOfferedCourse = new CurrentOfferedCourse();
	}
	
	public void offerCourse(Course course) {
		this.currentOfferedCourse.addCourse(course);
	}
	
	public void publishOfferedCourse() {
		int counter = 0 ;
		System.out.println("Offered Courses List:");
		for (Course course : this.currentOfferedCourse.getCourseList()) {
			System.out.println(++counter + "." + course.getId());
		}
	}
	
	public void increaseSeatCapacity(Course course, int size) {
		course.setSeatCapacity(course.getSeatCapacity() + size);
	}
	
	
	public void seeCourseStatus() {
		
		for (Course course : this.currentOfferedCourse.getCourseList()) {
			System.out.println("Course ID: "+course.getId()+", Seat Capacity: "+ course.getSeatCapacity() + ", Number of Students: " + course.getNumOfStudent());
		}
		
	}
}
