import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Registration {
	
	private Course[] courseList = new Course[0];
	
	public Registration() {
		
	}
	
	public void addCourse(Course course) {
		Course[] changedCourse = Arrays.copyOf(courseList, courseList.length +1);
		changedCourse[courseList.length] = course;
		courseList = changedCourse;
	}
	
	public void deleteCourse(Course course) {
		List<Course> temp = new ArrayList<>(Arrays.asList(courseList));
		temp.remove(course);
		courseList = temp.toArray(new Course[temp.size()]);
	}
	
	public Course[] getCourseList() {
		return courseList;
	}
}

