
public class Course {
	
	private String id;
	private String title;
	private int credit;
	private int tutionperCredit;
	private int numOfStudent;
	private int seatCapacity;
	
	public Course(String id, String title, int credit, int tutionperCredit, int numOfStudent, int seatCapacity) {
		super();
		this.id = id;
		this.title = title;
		this.credit = credit;
		this.tutionperCredit = tutionperCredit;
		this.numOfStudent = 0;
		this.seatCapacity = seatCapacity;
	}
	
	public Course(String id, String title, int credit, int tutionperCredit) {
		super();
		this.id = id;
		this.title = title;
		this.credit = credit;
		this.tutionperCredit = tutionperCredit;
		this.numOfStudent = 0;
		this.seatCapacity = 3;
	}
	
	@Override
	public String toString() {
		return "Course [id=" + id + ", title=" + title + ", credit=" + credit + ", tutionperCredit=" + tutionperCredit
				+ ", numOfStudent=" + numOfStudent + ", seatCapacity=" + seatCapacity + "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCredit() {
		return credit;
	}
	public void setCredit(int credit) {
		this.credit = credit;
	}
	public int getTutionperCredit() {
		return tutionperCredit;
	}
	public void setTutionperCredit(int tutionperCredit) {
		this.tutionperCredit = tutionperCredit;
	}
	public int getNumOfStudent() {
		return numOfStudent;
	}
	public void setNumOfStudent(int numOfStudent) {
		this.numOfStudent = numOfStudent;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	
	public int getSubTotal() {
		return this.credit * this.tutionperCredit;
	}
}
