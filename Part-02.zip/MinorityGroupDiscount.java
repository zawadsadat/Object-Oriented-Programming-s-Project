
public class MinorityGroupDiscount implements IDiscountStrategy {

	@Override
	public int getTotal(Registration reg) {
		return (int) (reg.getTotal() * 0.1);
	}

}
