
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CurrentOfferedCourse implements Iterable<Course>{
	
	
	public CurrentOfferedCourse() {
		
	}
	
	private List<Course> cList = new ArrayList<Course>();
	
	public void addCourse(Course course) {
		cList.add(course);
	}
	
	public Course getCourse(Course course) {
		for(Course ex : cList) {
			if (ex.getTitle() == course.getTitle()) {
				return course;
			}
		}
		return null;
	}
	
	public List<Course> getCourseList() {
		return cList;
	}

	@Override
	public Iterator<Course> iterator() {
		return cList.iterator();
	}
}