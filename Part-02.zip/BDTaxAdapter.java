
public class BDTaxAdapter implements IExtraFeeCalculator {

	@Override
	public int getExtraAmount(int courseTotal) {
		return (int) new BDTaxCalculator().calculateVatAmount(courseTotal);
	}

}