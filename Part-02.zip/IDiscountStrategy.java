
public interface IDiscountStrategy {
	
	public int getTotal(Registration reg);

}
