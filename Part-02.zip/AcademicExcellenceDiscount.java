
public class AcademicExcellenceDiscount implements IDiscountStrategy{

	@Override
	public int getTotal(Registration reg) {
		return (int) (reg.getTotal() * 0.2);
	}

}
