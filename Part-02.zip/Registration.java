import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Registration implements Iterable<Course>{
	
	public Registration() {
		this.date = LocalDateTime.now();
	}
	
	private List<Course> courseList = new ArrayList<>();
	
	private IExtraFeeCalculator eFeeCalculator;
	
	private List<IDiscountStrategy> applicableDiscounts=  new ArrayList<>();
	
	private LocalDateTime date ;
	
	public IExtraFeeCalculator geteFeeCalculator() {
		return eFeeCalculator;
	}

	public void seteFeeCalculator(IExtraFeeCalculator eFeeCalculator) {
		this.eFeeCalculator = eFeeCalculator;
	}

	public void addCourse(Course course) {
		courseList.add(course);
	}
	
	public void deleteCourse(Course course) {
		courseList.remove(course);
	}
	
	public List<Course> getCourseList() {
		return courseList;
	}

	@Override
	public Iterator<Course> iterator() {
		return this.courseList.iterator();
	}
	
	public String getLocalDateTime() {
		return this.date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss"));
	}
	
	public void setApplicableDiscounts(IDiscountStrategy discountStrategy) {
		this.applicableDiscounts.add(discountStrategy);
	}
	
	public double getTotal() {
		return this.courseList.stream().mapToInt(Course::getSubTotal).sum() * 1.0;
	}
	
	
	public int getExtraFeeAmount(Admin admin) {
		IExtraFeeCalculator eFeeCalculator = admin.getExtraFeeCalculator();
		return eFeeCalculator.getExtraAmount((int) (getTotal()));
	}
	
	public int getGrandTotal(Admin admin) {
		return (int)this.getTotal() + this.getExtraFeeAmount(admin);
	}
	
	public int getDiscountAmount() {
		int academicExcellenceDiscount = 0; 
		int freedomFighterDiscount = 0;
		int minorityGroupDiscount = 0;
		for(IDiscountStrategy discountStrategy : this.applicableDiscounts) {
			if(AcademicExcellenceDiscount.class.getName().equalsIgnoreCase(discountStrategy.getClass().asSubclass(discountStrategy.getClass()).getName())) {
				academicExcellenceDiscount = discountStrategy.getTotal(this);
			}
			if(MinorityGroupDiscount.class.getName().equalsIgnoreCase(discountStrategy.getClass().asSubclass(discountStrategy.getClass()).getName())) {
				minorityGroupDiscount = discountStrategy.getTotal(this);
			}
			if(FreedomFighterDiscount.class.getName().equalsIgnoreCase(discountStrategy.getClass().asSubclass(discountStrategy.getClass()).getName())) {
				freedomFighterDiscount = discountStrategy.getTotal(this);
			}
		}
		return Math.max(academicExcellenceDiscount, Math.max(freedomFighterDiscount, minorityGroupDiscount));
	}
	
	public int getPayableAmount(int grandTotal, int discount) {
		return grandTotal - discount;
	}
}
