public class Student {
	
	private String name;
	
	private int id;
	
	private double cgpa;
	
	private char freedomFighterStatus;
	
	private char minorityGroupStatus;
	
	private Registration reg;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public Registration getReg() {
		return reg;
	}

	public void setReg(Registration reg) {
		this.reg = reg;
	}
	
	public char getFreedomFighterStatus() {
		return freedomFighterStatus;
	}

	public void setFreedomFighterStatus(char freedomFighterStatus) {
		this.freedomFighterStatus = freedomFighterStatus;
	}

	public char getMinorityGroupStatus() {
		return minorityGroupStatus;
	}

	public void setMinorityGroupStatus(char minorityGroupStatus) {
		this.minorityGroupStatus = minorityGroupStatus;
	}

	public Student(String name, int id, double cgpa, char freedomFighterStatus, char minorityGroupStatus) {
		super();
		this.name = name;
		this.id = id;
		this.cgpa = cgpa;
		this.freedomFighterStatus = freedomFighterStatus;
		this.minorityGroupStatus = minorityGroupStatus;
	}
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + ", cgpa=" + cgpa + ", freedomFighterStatus="
				+ freedomFighterStatus + ", minorityGroupStatus=" + minorityGroupStatus + ", reg=" + reg + "]";
	}
	
	public void makeNewRegistration() {
		this.reg = new Registration();
	}
	
	public void addCourse(Course course) {
		if(course.getNumOfStudent() == course.getSeatCapacity()) {
			System.out.println(course.getId()+" can not be added.Seat is Full !!");
		} else {
			int totalCurrentCredit = 0;
			boolean isExist = false;
			for(Course ec : this.getReg().getCourseList()) {
				totalCurrentCredit += ec.getCredit();
				if(!isExist && ec.getId() == course.getId()) {
					isExist = true;
				}
			}
			int availCredit = this.getCgpa() >= 3.5 ? 18: 12;
			if(course.getCredit() > availCredit - totalCurrentCredit) {
				System.out.println(this.getName() + ": You can not take "+ course.getId() +". You exceed the "+ availCredit +" credits limit.");
			} else if(!isExist){
				this.getReg().addCourse(course);
				course.setNumOfStudent(course.getNumOfStudent() + 1); 
			}
		}
	}
	
	public void dropCourse(Course course) {
		this.getReg().deleteCourse(course);
		course.setNumOfStudent(course.getNumOfStudent() - 1);
	}
	
	public Registration getRegistration() {
		return this.reg;
	}
	
	public String printRegisteredCourse() {
		StringBuffer allCourses = new StringBuffer();
		System.out.printf("Course Id:\tCourse Title:\n");
		System.out.printf("========================================\n");
		for (Course course : this.getReg().getCourseList()) {
			System.out.printf(course.getId() + "\t" + course.getTitle() + "\n");
		}
		System.out.printf("========================================\n");
		return allCourses.toString();
	}
	
	public void setDiscounts() {
		if(this.cgpa > 3.5) { 
			this.reg.setApplicableDiscounts(new AcademicExcellenceDiscount());
		}
		if(freedomFighterStatus == 'Y') { 
			this.reg.setApplicableDiscounts(new FreedomFighterDiscount());
		}
		if(minorityGroupStatus == 'Y') { 
			this.reg.setApplicableDiscounts(new MinorityGroupDiscount());
		}
	}
	public String getBillingInfo() {
		return "Total Course Fee:\n" + 
				"Extra Fee: \n" + 
				"Discount: \n" + 
				"Payable Amount";
	}
	public void printRegistrationSlip(Long billingID, Admin admin) {
		System.out.println("Registration Time: " + this.reg.getLocalDateTime());
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("Name: "+ this.name + ", ID: " + this.id + ", CGPA:" + this.cgpa);
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("Course Id:\tCourse Title:");
		System.out.println("========================================");
		printBillingInfo(billingID, admin);
	}
	
	public void printBillingInfo(Long billingID, Admin admin) {
		setDiscounts();
		System.out.println("Billing Info: (ID: " + billingID + ")"); 
		System.out.println("-------------------------------");
		System.out.println("Total Course Fees:" + (int)this.getReg().getTotal());
		System.out.println("Extra Fee:\t+ " + this.getReg().getExtraFeeAmount(admin));
		System.out.println("-------------------------------");
		int grandTotal = this.getReg().getGrandTotal(admin);
		System.out.println("Grand Total:      " + grandTotal);
		int discount = this.getReg().getDiscountAmount();
		System.out.println("Discount: -------- " + discount);
		System.out.println("-------------------------------");
		System.out.println("Payable Amount:   " + this.getReg().getPayableAmount(grandTotal,discount) + "\n");
	}
}
