
public class Tasks {
	public static void main(String[] args) {
        Admin admin = new Admin();
		
		Course CSE115 = new Course("CSE115", "Programming Language-I", 3, 6000);
		Course CSE173 = new Course("CSE173", "Discrete Mathematics", 3, 6000);
		Course CSE231 = new Course("CSE231", "Digital Logic Design", 3, 6000);
		Course CSE311 = new Course("CSE311", "Database Systems", 3, 6000);
		Course CSE215 = new Course("CSE215", "Programming Language-II", 3, 6000);
		Course CSE225 = new Course("CSE225", "Data Structures and Algorithms", 3 ,6000);
		Course CSE323 = new Course("CSE323", "Operating Systems Design", 3, 6000);
		Course CSE373 = new Course("CSE373", "Design and Analysis of Algorithms", 3, 6000);

		Student s1 = new Student("Farhan Islam", 1631728042, 270, 'Y','N');
		Student s2 = new Student("Sadia Sultana", 1821347042, 3.44, 'N','Y');
		Student s3 = new Student("Sanjida Akter", 2021746042, 3.65, 'N','N');
		Student s4 = new Student("Farhan Bhuiyan", 1923147042, 3.94, 'N', 'N');
		Student s5 = new Student("Mahmudul Hoque", 1524137042, 2.14,'Y', 'N');
		
		
		admin.offerCourse(CSE115);
		admin.offerCourse(CSE173);
		admin.offerCourse(CSE215);
		admin.offerCourse(CSE225);
		admin.offerCourse(CSE231);
		admin.offerCourse(CSE311);
		admin.offerCourse(CSE323);
		admin.offerCourse(CSE373);
		
		admin.publishOfferedCourse();
		
		s1.makeNewRegistration();
		s2.makeNewRegistration();
		s3.makeNewRegistration();
		
		s1.addCourse(CSE115);
		s1.addCourse(CSE173);
		
		s2.addCourse(CSE115);
		s2.addCourse(CSE215);
		s2.addCourse(CSE225);
		
		s3.addCourse(CSE115);
		s3.addCourse(CSE225);
		s3.addCourse(CSE311);
		
		admin.seeCourseStatus();
		
		s4.makeNewRegistration();
		s5.makeNewRegistration();
		
		s4.addCourse(CSE115);
		s4.addCourse(CSE225);
		
		s5.addCourse(CSE115);
		s5.addCourse(CSE173);
		s5.addCourse(CSE215);
		
		admin.increaseSeatCapacity(CSE115, 2);
		
		s4.addCourse(CSE115);
		s5.addCourse(CSE115);
		
		admin.seeCourseStatus();
		
		s3.addCourse(CSE173);
		s3.addCourse(CSE215);
		s3.addCourse(CSE231);
		s3.addCourse(CSE323);
		
		s5.addCourse(CSE311);
		s5.addCourse(CSE373);
		
		admin.seeCourseStatus();
		
		s3.dropCourse(CSE311);
		
		System.out.println(s3.printRegisteredCourse());
		
		// task -2
		s1.printBillingInfo(1631728042L, admin);
		s2.printBillingInfo(1821347042L, admin);
		admin.setExtraFeeCalculator(new BDTaxAdapter());
		s3.printBillingInfo(2021746042L, admin);
		s4.printBillingInfo(1923147042L, admin);
		s5.printRegistrationSlip(1524137042L, admin);
	}
}
