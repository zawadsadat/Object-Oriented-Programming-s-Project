
public class DevelopmentFeeCalculator implements IExtraFeeCalculator{

	@Override
	public int getExtraAmount(int courseTotal) {
		return courseTotal * 10/100;
	}

}