
public class BDTaxCalculator {
	
	public double calculateVatAmount(int total) {
		return total * 0.15;
		
	}
	
}
